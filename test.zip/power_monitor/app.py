import json
import time
import os
import webbrowser
import webview
from datetime import datetime
from flask import Flask, Response, render_template, stream_with_context, request
import logging
import coloredlogs
import helper.get_data as get_data

app = Flask(__name__)
log = logging.getLogger(__name__)

level = 'INFO'
coloredlogs.install(
    level   = level,
    fmt     = '%(levelname).1s (%(asctime)s.%(msecs)03d) %(name)s: %(message)s',
    datefmt = '%H:%M:%S',
)
log.critical('running...')


def render_sidebar_chip_info():
    attr = get_data.chip_info()
    if attr:
        return render_template("sidebar_chip_info.html", attr=attr).replace('\n', '')
    else:
        return ''

def render_sidebar_device():
    with open('config/devices.json', 'r') as f:
        config = json.loads(f.read())
    devices = []
    for x in config['devices']:
        devices.append({'value': f'{x["cpu_ssh_ip"]}', 'label': f'{x["cpu_ssh_ip"]}'})
    devices[0]['selected'] = True

    return render_template("sidebar_device.html", devices=devices).replace('\n', '')

def render_chart():
    with open('config/config.json', 'r') as f:
        config = json.loads(f.read())

    chart_all = ""
    for x in config['chart']:
        if not x['show']:
            continue
        chart_all = chart_all + render_template(f"{x['name']}.html")
    return chart_all.replace('\n', '')


@app.route('/api/open_config_dir', methods=['GET'])
def open_config_dir():
    relative_path = 'config'
    absolute_path = os.path.abspath(relative_path)
    webbrowser.open('file://' + absolute_path + '/')
    return {'code': 200}

@app.route('/api/connect_device', methods=['POST'])
def connect_device():
    data = request.form.to_dict()
    log.info(f'/api/connect_device: {data}')
    if data['connected']:
        ret = get_data.connect(data['ip'])
    else:
        ret = get_data.disconnect(data['ip'])
    if ret:
        return {'code': 200, 'sidebar_chip_info': render_sidebar_chip_info(), 'chip_info': get_data.device_info}
    else:
        return {'code': 400}

@app.route('/api/get_chart_data', methods=['GET'])
def get_chart_data():
    data = get_data.chart_data()
    return data


@app.route('/')
def index():
    sidebar_device = render_sidebar_device()
    sidebar_chip_info = render_sidebar_chip_info()
    chart_all = render_chart()
    return render_template('index.html',
        sidebar_device=sidebar_device,
        sidebar_chip_info=sidebar_chip_info,
        chart_all=chart_all
    )


class WebviewApi:
    def __init__(self) -> None:
        self._window = None

    def set_window(self, window):
        self._window = window

    def quit(self):
        self._window.destroy()


if __name__ == '__main__':
    # app.run(
    #     debug=True,
    #     threaded=True,
    #     host='0.0.0.0',
    #     port=5000
    # )

    api = WebviewApi()
    window = webview.create_window(
        title = 'Power Monitor',
        url = app,
        fullscreen = False,
        width = 1600,          # 自定义窗口大小
        height = 900,
        resizable = True,      # 固定大小可调节
        text_select = True,    # 不禁止选择文字内容
        confirm_close = True,  # 关闭时提示
        js_api = api           # 将上面实例化后的Api对象传给前端js调用
    )
    api.set_window(window)
    webview.start(localization={'global.quitConfirmation': u'确定关闭？'})





