import json
import time
import os
import logging
log = logging.getLogger(__name__)

selected_device = None
device_info = {}

def connect(ip):
    global selected_device
    global device_info
    selected_device = ip
    with open('config/devices.json', 'r') as f:
        config = json.loads(f.read())
    for x in config['devices']:
        if x['cpu_ssh_ip'] == selected_device:
            device_info = x
            log.info(f'device_info: {device_info}')
            break
    return True

def disconnect(ip):
    global selected_device
    selected_device = None
    return True

def chart_data():
    data = {
        'chart_storage': {
            'data': [20, 50],
            'categories': ['/root (12/55G)', '/home (48/102G)']
        },
        'chart_mem': {
            'data': [70],
            'labels': ['Mem (103/288G)']
        },
        'table_process': [
            ['12535', '3.15', '0.02', 'watchdog'],
            ['12535', '3.15', '0.02', 'watchdog'],
            ['12535', '3.15', '0.02', 'watchdog'],
            ['12535', '3.15', '0.02', 'watchdog'],
            ['12535', '3.15', '0.02', 'watchdog'],
        ],
        'table_power_all': [
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
            ['watchdog', '12535', '3.15', '0.02'],
        ],
        'chart_freq_bar': {
            'data': [400, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500,
            550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550,
            700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700,
            500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500,
            400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550, 700, 500, 400, 600, 500, 550]
        },
        'chart_temperature': {
            'data': [
                {'name': "thermal_zone0",
                'data': [28, 29, 30, 29, 30, 28, 29]},
                {'name': "thermal_zone1",
                 'data': [29, 30, 29, 28, 29, 30, 29]}
            ]
        },
        'chart_power_total': {
            'data': [68, 80, 75, 84, 56, 77, 60],
        },
        'chart_freq_heatmap': {
            'data': [
                {'name': 'core 10',
                'data': [300,700,1000,1300,1700,1800,1100,2200]},
                {'name': 'core 20',
                'data': [500,600,700,800,900,600,1800,800]},
                {'name': 'core 30',
                'data': [500,600,700,300,900,600,700,3520]},
                {'name': 'core 40',
                'data': [500,600,700,800,2201,900,700,800]},
                {'name': 'core 50',
                'data': [500,600,700,800,900,900,700,800]},
                {'name': 'core 60',
                'data': [500,600,700,800,900]},
            ]
        },
        'chart_voltage': {
            'data': [
                {'x': 'New Delhi', 'y': 218},
                {'x': 'Kolkata', 'y': 149},
                {'x': 'Mumbai', 'y': 184},
                {'x': 'Ahmedabad', 'y': 55},
                {'x': 'Bangaluru', 'y': 84},
                {'x': 'Pune', 'y': 31},
                {'x': 'Chennai', 'y': 70},
                {'x': 'Jaipur', 'y': 30},
                {'x': 'Surat', 'y': 44},
                {'x': 'Hyderabad', 'y': 68},
            ]
        },
        'chart_electric': {
            'data': [
                {'x': 'New Delhi', 'y': 218},
                {'x': 'Kolkata', 'y': 149},
                {'x': 'Mumbai', 'y': 184},
                {'x': 'Ahmedabad', 'y': 55},
                {'x': 'Bangaluru', 'y': 84},
                {'x': 'Pune', 'y': 31},
                {'x': 'Chennai', 'y': 70},
                {'x': 'Jaipur', 'y': 30},
                {'x': 'Surat', 'y': 44},
                {'x': 'Hyderabad', 'y': 68},
            ]
        },
        'chart_power_treemap': {
            'data': [
                {'x': 'New Delhi', 'y': 218},
                {'x': 'Kolkata', 'y': 149},
                {'x': 'Mumbai', 'y': 184},
                {'x': 'Ahmedabad', 'y': 55},
                {'x': 'Bangaluru', 'y': 84},
                {'x': 'Pune', 'y': 31},
                {'x': 'Chennai', 'y': 70},
                {'x': 'Jaipur', 'y': 30},
                {'x': 'Surat', 'y': 44},
                {'x': 'Hyderabad', 'y': 68},
            ]
        },
    }
    return data

def chip_info():
    global device_info
    info = {
        'chip_type': None,
        'chip_index': None,
        'chip_cpus': 96,
        'freq_highest': None,
        'freq_max': 2200,
        'freq_min': 400,
        'bios_config': [
            {'name': 'LPI', 'enable': True},
            {'name': 'SMT', 'enable': True},
            {'name': 'Turbo', 'enable': False},
        ],
        'power_caping': '',
        'power_sve': '',
        'overtemp_protect_pid': '',
        'overtemp_protect_lv1': '',
        'overtemp_protect_lv2': ''
    }
    if selected_device:
        with open('config/config.json', 'r') as f:
            config = json.loads(f.read())
        info.update(config['specs'].get(device_info['chip_type']))
        info.update(device_info)
        device_info = info
        return device_info
    else:
        return None