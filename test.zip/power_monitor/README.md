

## env
```
pip install flask
pip install coloredlogs
pip install pywebview
```

## run
```
python app.py
```

# 打包
- https://pypi.org/project/auto-py-to-exe/
```
pip install auto-py-to-exe
auto-py-to-exe
```

## 其他
- flask：开web server
- bootstrap：自适应html
- apexcharts：js生成图表 https://apexcharts.com/docs
- pywebview：web转桌面应用程序
- auto-py-to-exe：py打包成exe


